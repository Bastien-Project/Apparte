<nav class="sidebar close">
    <header>
        <div class="image-text">
            <div class="text logo-text">
                <p class="name">Projet Apparté</p>
            </div>
        </div>

        <i class="fa-solid fa-circle-chevron-right toggle"></i>
    </header>

    <div class="menu-bar">
        <div class="menu">
            <ul class="menu-links">
                <li class="nav-link">
                    <a href="index.php">
                        <i class="fa-solid fa-house"></i> &nbsp; Accueil
                    </a>
                </li>

                <li class="nav-link">
                    <a href="chambre.php">
                        <i class="fa-solid fa-bed"></i> &nbsp;Chambre
                    </a>
                </li>

                <li class="nav-link">
                    <a href="#">
                        <i class="fa-solid fa-calendar-days"></i> &nbsp; Réservations</span>
                    </a>
                </li>
                <li class="nav-link">
                    <a href="#">
                        <i class="fa-solid fa-user"></i> &nbsp; Profil
                    </a>

                <li class="nav-link">
                    <a href="#">
                        <i class="fa-solid fa-right-to-bracket"></i> &nbsp; Connection
                    </a>
                </li>
                <li class="nav-link">
                    <a href="#">
                        <i class="fa-solid fa-right-to-bracket reverse"></i> &nbsp; Logout
                    </a>
            </ul>
        </div>
    </div>

</nav>
<!--navigation bar -->

<!-- nav bar en dark ou light mode-->
<script>
    const body = document.querySelector('body'),
        sidebar = body.querySelector('nav'),
        toggle = body.querySelector(".toggle"),
        searchBtn = body.querySelector(".search-box"),
        modeSwitch = body.querySelector(".toggle-switch"),
        modeText = body.querySelector(".mode-text"),
        texte = body.querySelector(".texte");

    toggle.addEventListener("click", () => {
        sidebar.classList.toggle("close");
    })

    searchBtn.addEventListener("click", () => {
        sidebar.classList.remove("close");
    })
</script>